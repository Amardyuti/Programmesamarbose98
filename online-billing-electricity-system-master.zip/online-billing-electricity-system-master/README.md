# Online-Electricity-Billing-System
# It's my Design engineering Project.

In this Android Application, Unit Reader will enter the meter number and current unit from the Electricity meter. After that, automatically calculate the amount and it will send soft copy of the bill to the customer through registered E-mail Id. I have used the back-end technology as Firebase.

Login Screen, Common for both user Unit Reader and Customer.

<img src="/screenshots/login.png" width="30%" />

Add Bill from Unit reader.

<img src="/screenshots/add_bill_from_unit_reader.png" width="30%" />

Confirm Dialog.

<img src="/screenshots/confirm_dialog.png" width="30%" />

Customer Menu.

<img src="/screenshots/user_menu.png" width="30%" />

Customer Bill Details.

<img src="/screenshots/user_bill_details.png" width="30%" />

Contant Us for any Query.

<img src="/screenshots/contact_us.png" width="30%" />
