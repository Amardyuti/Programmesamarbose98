package EventManagementCompany;

/**
 *
 * @author n00145647
 */
public interface EventManagementInterface {
    
   public String display();
    
}
