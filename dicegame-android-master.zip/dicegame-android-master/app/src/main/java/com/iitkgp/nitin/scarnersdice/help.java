package com.iitkgp.nitin.scarnersdice;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by ashish on 14/1/17.
 */

public class help extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.help);
    }
}
