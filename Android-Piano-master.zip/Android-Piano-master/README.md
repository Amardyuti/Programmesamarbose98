# Android-Piano
An easy to use virtual Piano application in Android which makes use of the Android MIDI (Musical Instrument Digital Interface) API to construct each note. Features a scrollable 5 octave UI with smooth graphics and the ability to record and playback songs.
