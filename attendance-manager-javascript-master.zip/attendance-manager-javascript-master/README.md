# attendance-manager

## Features
- Upload your timetable by filling a table with time and weekdays column --_completed_
- gives you real time notifications of lectures according 2 the timetable uploaded --_completed_ 
- update the timetable whenever needed --_completed_
- calculates each subject attendance for each month (underdevelopment)
