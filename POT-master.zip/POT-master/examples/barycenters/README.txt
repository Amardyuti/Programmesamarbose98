

Wasserstein barycenters
-----------------------