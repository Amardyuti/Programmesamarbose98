Examples gallery
================

This is a gallery of all the POT example files.


OT and regularized OT
---------------------