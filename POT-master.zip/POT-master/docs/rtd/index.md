<meta http-equiv="refresh" content="0; URL=https://PythonOT.github.io">

# POT: Python Optimal Transport

The documentation has been moved to : [https://PythonOT.github.io](https://PythonOT.github.io)