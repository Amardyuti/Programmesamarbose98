<!DOCTYPE html>
<html>
<head>
<title>Online Marriage Regitration System :: Home Page</title>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--//Meta tag Keywords -->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/><!--stylesheet-->
	<link rel="stylesheet" href="css/font-awesome.css"><!--font_aswesome_icons-->
	<link href="//fonts.googleapis.com/css?family=Basic" rel="stylesheet"><!--online-fonts-->
	<link href="//fonts.googleapis.com/css?family=Titillium+Web" rel="stylesheet"><!--online-fonts-->
</head>
<body>
	<div class="w3ls-icons">
		<ul style="font-size: 30px">
			<li><a href="admin/login.php" style="color: #fff;"> Admin</a></li>
			<li style="padding-left: 20px"><a href="user/login.php" style="color: #fff;"> User</a></li>
		</ul>
	</div>
<div class="w3ls-head">
		<h1>Online Marriage Regitration System</h1>
</div>
<div class="w3ls-content">
	<div class="w3ls-headding">
		<h2> <img src="images/5b9d320a2000002d00fdde0f.jpeg"></h2>
		<p>We are launching the most awesome site ever. It's gonna be legendary</p>
	</div>
	
</div>

<footer>&copy; 2020 Online Marriage Registration System</footer>
</body>
</html>