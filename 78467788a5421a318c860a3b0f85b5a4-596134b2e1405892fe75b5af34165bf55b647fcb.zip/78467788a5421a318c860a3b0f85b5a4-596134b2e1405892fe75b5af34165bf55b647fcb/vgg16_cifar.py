'''
Update of example of Keras VGG16 custom input shape

Using:
Keras==2.2.4
tensorflow-gpu==1.13.1
'''

import h5py, pickle
import numpy as np
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D, Dropout
from keras.applications.vgg16 import VGG16
from keras.utils import to_categorical

vgg16_weights = '/home/yohanesgultom/Downloads/vgg16_weights_tf_dim_ordering_tf_kernels_notop.h5'
dir_path = '/home/yohanesgultom/Downloads/cifar-10-python/cifar-10-batches-py'

def load_cfar10_batch(cifar10_dataset_folder_path, batch_id):
    with open(cifar10_dataset_folder_path + '/data_batch_' + str(batch_id), mode='rb') as file:
        # note the encoding type is 'latin1'
        batch = pickle.load(file, encoding='latin1')
    features = batch['data'].reshape((len(batch['data']), 3, 32, 32)).transpose(0, 2, 3, 1)
    labels = batch['labels']
    return np.array(features), to_categorical(labels)

X, y = load_cfar10_batch(dir_path, 1)
base_model = VGG16(include_top=False, weights=vgg16_weights, input_shape=(32, 32, 3))
# add a global spatial average pooling layer
# fully-connected layer and prediction layer
x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dense(512, activation='relu')(x)
x = Dropout(0.3)(x)
predictions = Dense(10, activation='softmax')(x)
# freeze vgg16 layers
for layer in base_model.layers:
    layer.trainable = False

model = Model(inputs=base_model.input, outputs=predictions)
model.summary()

model.compile(optimizer='rmsprop', loss='categorical_crossentropy')
model.fit(X, y)
